<?php
return array (
  0 => 
  array (
    'App\\Bootstrap' => 
    array (
      0 => 'C:\\Users\\david\\Documents\\GitHub\\web-project\\app\\Bootstrap.php',
      1 => 1643031901,
    ),
    'App\\Model\\World' => 
    array (
      0 => 'C:\\Users\\david\\Documents\\GitHub\\web-project\\app\\Model\\World.php',
      1 => 1656060503,
    ),
    'NasExt\\Forms\\Tests\\App\\Presenters\\BasePresenter' => 
    array (
      0 => 'C:\\Users\\david\\Documents\\GitHub\\web-project\\app\\Presenters\\BasePresenter.php',
      1 => 1629464631,
    ),
    'App\\Presenters\\EndpointPresenter' => 
    array (
      0 => 'C:\\Users\\david\\Documents\\GitHub\\web-project\\app\\Presenters\\EndpointPresenter.php',
      1 => 1656061145,
    ),
    'App\\Presenters\\Error4xxPresenter' => 
    array (
      0 => 'C:\\Users\\david\\Documents\\GitHub\\web-project\\app\\Presenters\\Error4xxPresenter.php',
      1 => 1643031901,
    ),
    'App\\Presenters\\ErrorPresenter' => 
    array (
      0 => 'C:\\Users\\david\\Documents\\GitHub\\web-project\\app\\Presenters\\ErrorPresenter.php',
      1 => 1643031901,
    ),
    'App\\Presenters\\HomepagePresenter' => 
    array (
      0 => 'C:\\Users\\david\\Documents\\GitHub\\web-project\\app\\Presenters\\HomepagePresenter.php',
      1 => 1656057873,
    ),
    'App\\Presenters\\LulPresenter' => 
    array (
      0 => 'C:\\Users\\david\\Documents\\GitHub\\web-project\\app\\Presenters\\LulPresenter.php',
      1 => 1656064053,
    ),
    'App\\Router\\RouterFactory' => 
    array (
      0 => 'C:\\Users\\david\\Documents\\GitHub\\web-project\\app\\Router\\RouterFactory.php',
      1 => 1643031901,
    ),
  ),
  1 => 
  array (
    'App\\Presenters\\LulDefaultTemplate' => 3,
    'App\\Presenters\\LulTemplate' => 3,
    'App\\Presenters\\HomepageDefaultTemplate' => 3,
    'App\\Presenters\\HomepageTemplate' => 3,
  ),
  2 => 
  array (
  ),
);
